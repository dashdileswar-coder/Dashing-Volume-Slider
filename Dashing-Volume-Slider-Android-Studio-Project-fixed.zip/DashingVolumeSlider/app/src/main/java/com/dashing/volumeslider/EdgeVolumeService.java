package com.dashing.volumeslider;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;
import android.view.*;
import android.widget.*;

public class EdgeVolumeService extends Service {
    public static final String ACTION_START="com.dashing.volumeslider.START";
    private WindowManager wm; private View edge; private View panel; private WindowManager.LayoutParams edgeParams,panelParams;
    private AudioManager audio; private SeekBar seek; private TextView value; private boolean tracking=false; private float downY; private int startVolume;
    private final String CHANNEL="dashing_volume_slider";

    @Override public void onCreate(){super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); audio=(AudioManager)getSystemService(AUDIO_SERVICE); createChannel(); startForeground(7,notification()); showEdge();}
    @Override public int onStartCommand(Intent i,int flags,int id){if(i!=null&&ACTION_START.equals(i.getAction())) showEdge(); return START_STICKY;}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Volume slider",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(){Intent open=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this); return b.setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setContentTitle("Dashing volume slider is active").setContentText("Swipe on the selected screen edge to adjust media volume").setContentIntent(pi).setOngoing(true).build();}
    private int type(){return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;}
    private void showEdge(){if(edge!=null)return; boolean right=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("edge","left").equals("right");
        int width=(int)(24*getResources().getDisplayMetrics().density); edge=new View(this); GradientDrawable gd=new GradientDrawable(); gd.setColor(0x553F51B5); float r=width/2f; gd.setCornerRadius(r); edge.setBackground(gd);
        edgeParams=new WindowManager.LayoutParams(width,WindowManager.LayoutParams.MATCH_PARENT,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        edgeParams.gravity=(right?Gravity.RIGHT:Gravity.LEFT)|Gravity.CENTER_VERTICAL;
        edgeParams.x=0; edgeParams.y=0; edge.setOnTouchListener((v,e)->handleEdge(e)); try{wm.addView(edge,edgeParams);}catch(Exception ex){edge=null;stopSelf();}}
    private boolean handleEdge(MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN: downY=e.getRawY(); startVolume=audio.getStreamVolume(AudioManager.STREAM_MUSIC); showPanel(); updateFromY(e.getRawY()); return true;
        case MotionEvent.ACTION_MOVE: if(panel!=null)updateFromY(e.getRawY()); return true;
        case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: tracking=false; if(panel!=null){panel.postDelayed(()->hidePanel(),650);} return true;
    }return true;}
    private void showPanel(){if(panel!=null)return; LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(12),dp(16),dp(12)); box.setGravity(Gravity.CENTER); GradientDrawable bg=new GradientDrawable(); bg.setColor(0xEE25232A); bg.setCornerRadius(dp(22)); box.setBackground(bg);
        value=new TextView(this); value.setTextColor(Color.WHITE); value.setTextSize(14); value.setGravity(Gravity.CENTER); box.addView(value,new LinearLayout.LayoutParams(dp(150),-2)); seek=new SeekBar(this); seek.setMax(Math.max(1,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))); seek.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC)); box.addView(seek,new LinearLayout.LayoutParams(dp(170),-2)); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int n,boolean u){audio.setStreamVolume(AudioManager.STREAM_MUSIC,n,0);value.setText("Media volume  "+n+" / "+s.getMax());}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        panel=box; panelParams=new WindowManager.LayoutParams(-2,-2,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT); panelParams.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL; panelParams.y=dp(70); try{wm.addView(panel,panelParams);}catch(Exception ex){panel=null;}}
    private void updateFromY(float y){if(seek==null)return; int h=getResources().getDisplayMetrics().heightPixels; float fraction=1f-(y/(float)h); int max=audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC); int v=Math.max(0,Math.min(max,Math.round(fraction*max))); seek.setProgress(v); if(value!=null)value.setText("Media volume  "+v+" / "+max);}
    private void hidePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){} panel=null;seek=null;value=null;}}
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onDestroy(){hidePanel();if(edge!=null){try{wm.removeView(edge);}catch(Exception ignored){}edge=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
