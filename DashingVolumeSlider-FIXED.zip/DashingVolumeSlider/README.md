# Dashing Volume Slider

An Android Studio rebuild inspired by the supplied legacy VolumeSlider APK.

## Behaviour in this first rebuild
- A slim touch strip on the selected left or right screen edge.
- Press and hold the strip; drag up/down to change media volume.
- A compact on-screen media-volume panel appears while interacting.
- A persistent notification indicates that the overlay service is running.
- Android 10+ (min SDK 29), compiled against Android 16 (API 36).

## Build
1. Open this folder in Android Studio (a recent version with Android Gradle Plugin 8.10.1 support).
2. Allow Gradle sync and install Android SDK Platform 36 if prompted.
3. Build > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install/use
1. Install the APK.
2. Open Dashing volume slider.
3. Grant "Display over other apps" permission.
4. Select Left edge or Right edge.
5. Tap Start volume slider.
6. Hold the narrow coloured edge strip and move your finger up/down.

## Important implementation notes
- This initial source build adjusts **media volume** only. It does not yet include the old app's premium multi-edge modes, app blacklist, brightness/rotation controls, or tutorial screens.
- Android/OEM battery management may stop long-running background services. The user must explicitly start the service after installation; auto-start is intentionally not enabled in this initial version.
- Android 13+ may ask for notification permission. Overlay permission is essential.
- Please test on a real device. OEM gesture navigation and edge-protection zones can affect how easily the strip is reached.


## Build fix
The edge overlay uses the supported five-argument `WindowManager.LayoutParams` constructor; gravity is assigned separately. Build in GitHub Actions with JDK 17 and Gradle 8.13.
