package com.dashing.volumeslider;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private RadioGroup sideGroup;
    private RadioButton left, right;
    private TextView status;
    private static final int OVERLAY_REQ = 51;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFFFFFFFF);
        getWindow().setNavigationBarColor(0xFFFFFFFF);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(24), dp(28), dp(24), dp(24)); root.setBackgroundColor(0xFFF7F5FA);
        TextView title = new TextView(this); title.setText("Dashing volume slider"); title.setTextSize(26); title.setTextColor(0xFF201A24); title.setTypeface(null, 1); root.addView(title);
        TextView sub = new TextView(this); sub.setText("Control media volume with a simple swipe on your screen edge."); sub.setTextSize(15); sub.setTextColor(0xFF625D67); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(8); root.addView(sub,sp);
        TextView choose = new TextView(this); choose.setText("Activation edge"); choose.setTextSize(17); choose.setTypeface(null,1); choose.setTextColor(0xFF29242F); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.topMargin=dp(32); root.addView(choose,cp);
        sideGroup = new RadioGroup(this); sideGroup.setOrientation(RadioGroup.HORIZONTAL);
        left = new RadioButton(this); left.setText("Left edge"); left.setId(View.generateViewId());
        right = new RadioButton(this); right.setText("Right edge"); right.setId(View.generateViewId()); sideGroup.addView(left); sideGroup.addView(right); root.addView(sideGroup);
        String saved=getPreferences(0).getString("edge","left"); (saved.equals("right")?right:left).setChecked(true);
        TextView note = new TextView(this); note.setText("How it works\n1. Enable the overlay permission.\n2. Tap Start service.\n3. Press and hold the thin strip at the selected screen edge.\n4. Move your finger up or down to change media volume."); note.setTextSize(14); note.setTextColor(0xFF514B56); note.setLineSpacing(dp(5),1f); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(24); root.addView(note,np);
        status = new TextView(this); status.setTextSize(13); status.setTextColor(0xFF6750A4); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2); stp.topMargin=dp(20); root.addView(status,stp);
        Button permission = new Button(this); permission.setText("Grant overlay permission"); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(18); root.addView(permission,pp);
        permission.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivityForResult(i,OVERLAY_REQ); } else updateStatus(); });
        Button start = new Button(this); start.setText("Start volume slider"); root.addView(start,new LinearLayout.LayoutParams(-1,-2));
        start.setOnClickListener(v -> { if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Please grant overlay permission first",Toast.LENGTH_LONG).show(); return; } saveEdge(); Intent i=new Intent(this,EdgeVolumeService.class); i.setAction(EdgeVolumeService.ACTION_START); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); status.setText("Status: running — use the selected screen edge"); });
        Button stop = new Button(this); stop.setText("Stop volume slider"); root.addView(stop,new LinearLayout.LayoutParams(-1,-2)); stop.setOnClickListener(v -> { stopService(new Intent(this,EdgeVolumeService.class)); status.setText("Status: stopped"); });
        TextView foot=new TextView(this); foot.setText("Dashing Volume Slider • Media volume • Android 10–16"); foot.setTextSize(12); foot.setTextColor(0xFF817B86); foot.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(28); root.addView(foot,fp);
        ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll); updateStatus();
    }
    private void saveEdge(){getPreferences(0).edit().putString("edge",right.isChecked()?"right":"left").apply();}
    private void updateStatus(){status.setText(Settings.canDrawOverlays(this)?"Overlay permission: granted":"Overlay permission: required");}
    @Override protected void onResume(){super.onResume(); if(status!=null) updateStatus();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
